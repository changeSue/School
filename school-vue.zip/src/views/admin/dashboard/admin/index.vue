<template>
	<div class="dashboard-editor-container"></div>
</template>

<script>
export default {
	name: 'DashboardAdmin',
	data() {
		return {}
	},
	methods: {}
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
	padding: 32px;
	background-color: #f6f6f6;
	position: relative;
	margin: -20px 0 0 -10px;

	.github-corner {
		position: absolute;
		top: 0px;
		border: 0;
		right: 0;
	}

	.chart-wrapper {
		background: #fff;
		padding: 16px 16px 0;
		margin-bottom: 32px;
	}
}

@media (max-width: 1024px) {
	.chart-wrapper {
		padding: 8px;
	}
}
</style>
