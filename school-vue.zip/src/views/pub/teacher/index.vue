<template></template>

<script>
</script>

<style lang="scss">
.el-timeline {
	padding: 30px 0 0 30px;
}
.el-timeline-item__tail {
	border-left: 2px solid red;
}
</style>
